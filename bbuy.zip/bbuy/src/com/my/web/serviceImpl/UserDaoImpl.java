package com.my.web.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import net.sf.ezmorph.bean.MorphDynaBean;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.stereotype.Service;

import com.my.web.entity.CustomerVO;
import com.my.web.entity.OrderVO;
import com.my.web.entity.ProductVO;
import com.my.web.service.UserDao;

@Service
public class UserDaoImpl implements UserDao {
	@Resource
	private SessionFactory sessionFactory;

	public boolean checkLogin(CustomerVO cust) {
		String hql = "from CustomerVO cu where cu.username='"
				+ cust.getUsername() + "' and cu.password='"
				+ cust.getPassword() + "' and cu.role='" + cust.getRole()
				+ "' ";
		Session session=sessionFactory.openSession();
		Query query = session.createQuery(hql);
		List<CustomerVO> custs = query.list();
		
		if(session!=null){
			session.close();
		}
		if (custs.size() < 1 || custs == null) {
			return false;
		} else {
			return true;
		}
	}

	public List<ProductVO> getProducts() {
		String hql = "from ProductVO ";
		Session session=sessionFactory.openSession();
		Query query = session.createQuery(hql);
		List<ProductVO> pros = query.list();
		
		if(session!=null){
			session.close();
		}
		return pros;
	}

	public void checkOut(List<MorphDynaBean> pros, CustomerVO cust) {
		List<OrderVO> orders = new ArrayList<OrderVO>();
		Session session=sessionFactory.openSession();
		for (MorphDynaBean pro : pros) {
			if (((Integer)pro.get("buyNum")).intValue() == 0)
				continue;
			OrderVO o = new OrderVO();
			StringBuilder hql=new StringBuilder("from ProductVO p where p.name='");
			hql.append((String) pro.get("pname")).append("' ");
			
			ProductVO p = (ProductVO)(session.createQuery(hql.toString())).uniqueResult();
			StringBuilder hql2=new StringBuilder("from CustomerVO c where c.username='");
			hql2.append(cust.getUsername()).append("' ");
			CustomerVO c=(CustomerVO)session.createQuery(hql2.toString()).uniqueResult();
			
			o.setPk_product(p);
			o.setPk_customer(c);
			o.setQuantity(((Integer) pro.get("buyNum")).shortValue());
			orders.add(o);
		}
		for (OrderVO order : orders) {
			session.save(order);
		}
		
		if(session!=null){
			session.close();
		}
	}
	
	public List<OrderVO> getMyOrders(CustomerVO cust) {
		String hql="from OrderVO ";
		Session session=sessionFactory.openSession();
		Query query=session.createQuery(hql);
		List<OrderVO> return_list = new ArrayList<OrderVO>();
		List<OrderVO> orders=query.list();
		for(OrderVO order:orders){
			if(order.getPk_customer().getUsername().equals(cust.getUsername())){
				return_list.add(order);
			}
		}
		if(session!=null){
			session.close();
		}
		return return_list;
	}
	public List<OrderVO> getCustsInfo() {
		StringBuilder hql=new StringBuilder("from OrderVO ");
		Session session = sessionFactory.openSession();
		Query query=session.createQuery(hql.toString());
		List<OrderVO> orders=query.list();
		
		if(session!=null){
			session.close();
		}
		return orders;
	}
	public void deleteCustInfo(List<MorphDynaBean> lists) {
		Session session=sessionFactory.openSession();
		for(MorphDynaBean m : lists){
			StringBuilder hql1=new StringBuilder("Delete from OrderVO o where o.pk_order=");
			hql1.append(((Integer)m.get("pk_order")).intValue());
			session.createQuery(hql1.toString()).executeUpdate();
			
			StringBuilder hql3=new StringBuilder("from CustomerVO c where c.username='");
			hql3.append((String)m.get("username")).append("' ");
			CustomerVO c=(CustomerVO)session.createQuery(hql3.toString()).uniqueResult();
			
			StringBuilder hql4=new StringBuilder("from OrderVO o where o.pk_customer=");
			hql4.append(c.getPk_customer());
			List list=session.createQuery(hql4.toString()).list();
			if(list==null || list.size()<1){
				StringBuilder hql2=new StringBuilder("Delete from CustomerVO c where c.username='" );
				hql2.append((String)m.get("username")).append("' ");
				session.createQuery(hql2.toString()).executeUpdate();
			}
		}
		if(session!=null)
			session.close();
	}
	public List<ProductVO> getSellersInfo() {
		StringBuilder hql=new StringBuilder("from ProductVO ");
		Session session=sessionFactory.openSession();
		List<ProductVO> pros=session.createQuery(hql.toString()).list();
		if(session!=null){
			session.close();
		}
		return pros;
	}
}
