package com.my.web.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.ezmorph.bean.MorphDynaBean;
import net.sf.json.JSONArray;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.my.web.entity.CustomerVO;
import com.my.web.entity.OrderVO;
import com.my.web.entity.ProductVO;
import com.my.web.service.UserDao;

@Controller
public class UserController {
	@Resource
	private UserDao userDao;
	
	private final Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping("/login")
	public String loginSuccess() {
		return "login";
	}

	@RequestMapping("/dologin")
	public void dologin(HttpServletRequest req, HttpServletResponse res) {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String role = req.getParameter("role");
		CustomerVO cust = new CustomerVO(username, password, role);
		
		try {
			if (!userDao.checkLogin(cust)) {
				req.getRequestDispatcher("login.com").forward(req, res);
			}
			req.getSession().removeAttribute("loginedUser");
			req.getSession().setAttribute("loginedUser",cust );
			if("user".equals(role)){
				req.getRequestDispatcher("login_success.com").forward(req, res);
			}else if("admin".equals(role)){
				req.getRequestDispatcher("adminLogin.com").forward(req, res);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
	}
	@RequestMapping("/login_success")
	public String loginSuccess(HttpServletRequest req, HttpServletResponse res){
		req.setAttribute("username", ((CustomerVO)req.getSession().getAttribute("loginedUser")).getUsername());
		List<ProductVO> pros=userDao.getProducts();
		req.setAttribute("pros", pros);
		
		return "login_success";
	}
	
	@RequestMapping("/checkOut")
	public String checkOut(HttpServletRequest req, HttpServletResponse res){
		String jsons=req.getParameter("json");
		
		List<MorphDynaBean> lists=JSONArray.toList(JSONArray.fromObject(jsons));
		CustomerVO cust=(CustomerVO)req.getSession().getAttribute("loginedUser");
		userDao.checkOut(lists,cust);
		
		return "trade_result";
	}
	@RequestMapping("/to_myorder")
	public String getMyOrders(HttpServletRequest req, HttpServletResponse res){
		CustomerVO cust=(CustomerVO)req.getSession().getAttribute("loginedUser");
		List<OrderVO> orders=userDao.getMyOrders(cust);
		
		req.setAttribute("orders", orders);
		return "my_orders";
	}
	@RequestMapping("/adminLogin")
	public String adminLogin(HttpServletRequest req, HttpServletResponse res){
		req.setAttribute("username", ((CustomerVO)req.getSession().getAttribute("loginedUser")).getUsername());
		
		return "adminLogin";
	}
	
	@RequestMapping("/customerManage")
	public String customerManage(HttpServletRequest req, HttpServletResponse res){
		List<OrderVO> orders=userDao.getCustsInfo();
		req.setAttribute("orders", orders);
		return "customer_manage";
	}
	@RequestMapping("/deleteCustomer")
	public String deleteCustomer(HttpServletRequest req, HttpServletResponse res){
		String jsons=req.getParameter("json");
		List<MorphDynaBean> lists=JSONArray.toList(JSONArray.fromObject(jsons));
		
		if(!(lists==null || lists.size()<1)){
			userDao.deleteCustInfo(lists);
		}
		return "admin_success";
	}
	@RequestMapping("/sellerManage")
	public String sellerManage(HttpServletRequest req, HttpServletResponse res){
		return "";
	}
}
