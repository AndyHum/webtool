package com.my.web.entity;

public class SellerVO {
	private Integer pk_sellor;
	private String name;
	private String address;
	private String phoneNumber;
	private String sellerID;
	private String registerDate;

	
	public Integer getPk_sellor() {
		return pk_sellor;
	}
	public void setPk_sellor(Integer pk_sellor) {
		this.pk_sellor = pk_sellor;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getSellerID() {
		return sellerID;
	}
	public void setSellerID(String sellerID) {
		this.sellerID = sellerID;
	}
	public String getRegisterDate() {
		return registerDate;
	}
	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}
	@Override
	public String toString() {
		return "SellerVO [pk_sellor=" + pk_sellor + ", name=" + name
				+ ", address=" + address + ", phoneNumber=" + phoneNumber
				+ ", sellerID=" + sellerID + ", registerDate=" + registerDate
				+ "]";
	}
	
}
