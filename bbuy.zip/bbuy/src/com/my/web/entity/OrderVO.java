package com.my.web.entity;

import java.sql.Date;

public class OrderVO {
	private Integer pk_order;
	
	private CustomerVO pk_customer;
	private ProductVO pk_product;
	
	private Short quantity;
	private Date ts;

	public Date getTs() {
		return ts;
	}

	public void setTs(Date ts) {
		this.ts = ts;
	}

	public Integer getPk_order() {
		return pk_order;
	}

	public void setPk_order(Integer pk_order) {
		this.pk_order = pk_order;
	}

	public CustomerVO getPk_customer() {
		return pk_customer;
	}

	public void setPk_customer(CustomerVO pk_customer) {
		this.pk_customer = pk_customer;
	}

	public ProductVO getPk_product() {
		return pk_product;
	}

	public void setPk_product(ProductVO pk_product) {
		this.pk_product = pk_product;
	}

	public Short getQuantity() {
		return quantity;
	}

	public void setQuantity(Short quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Order [pk_order=" + pk_order + ", pk_customer=" + pk_customer
				+ ", pk_product=" + pk_product + ", quantity=" + quantity + "]";
	}
	
	
}
