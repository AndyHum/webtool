package com.my.web.entity;

public class ProductVO {
	private Integer pk_product;
	private String name;
	private Double price;
	private Short quantity;
	private SellerVO pk_seller;
	
	
	public SellerVO getPk_seller() {
		return pk_seller;
	}
	public void setPk_seller(SellerVO pk_seller) {
		this.pk_seller = pk_seller;
	}
	public Integer getPk_product() {
		return pk_product;
	}
	public void setPk_product(Integer pk_product) {
		this.pk_product = pk_product;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Short getQuantity() {
		return quantity;
	}
	public void setQuantity(Short quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "ProductVO [pk_product=" + pk_product + ", name=" + name
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}
	
}
