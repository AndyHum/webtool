package com.my.web.entity;

public class CustomerVO {
	private Integer pk_customer;
	private String name;
	private String dob;
	private String phoneNumber;
	private String country;
	private Short sex;
	private String accountID;
	private String username;
	private String password;
	private String role;
	

	
	public CustomerVO() {
		super();
	}
	public CustomerVO(String username, String password, String role) {
		super();
		this.username = username;
		this.password = password;
		this.role = role;
	}
	public Integer getPk_customer() {
		return pk_customer;
	}
	public void setPk_customer(Integer pk_customer) {
		this.pk_customer = pk_customer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Short getSex() {
		return sex;
	}
	public void setSex(Short sex) {
		this.sex = sex;
	}
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "CustomerVO [pk_customer=" + pk_customer + ", name=" + name
				+ ", dob=" + dob + ", phoneNumber=" + phoneNumber
				+ ", country=" + country + ", sex=" + sex + ", accountID="
				+ accountID + ", username=" + username + ", password="
				+ password + ", role=" + role + "]";
	}
	
}
