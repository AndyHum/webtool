package com.my.web.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.filter.OncePerRequestFilter;

public class SessionFilter extends OncePerRequestFilter{

	@Override
	protected void doFilterInternal(HttpServletRequest req,
			HttpServletResponse res, FilterChain arg2)
			throws ServletException, IOException {
		String[] notFilter = new String[] { "dologin.com" }; 
		String uri=req.getRequestURI();
		
		boolean flag=true;
		for(String s : notFilter){
			if(uri.indexOf(s)!=-1){
				flag=false;
				break;
			}
		}
		if(uri.indexOf("login.com")!=-1){
			req.getSession().removeAttribute("loginedUser");
		}
		if(flag){
			Object obj = req.getSession().getAttribute("loginedUser");
			if (null == obj) {  
                // ���session�в����ڵ�¼��ʵ�壬�򵯳�����ʾ���µ�¼  
                // ����request��response���ַ�������ֹ����  
                req.setCharacterEncoding("UTF-8");  
                res.setCharacterEncoding("UTF-8");
                
                req.getRequestDispatcher("login.com").forward(req, res);
			}else{
				arg2.doFilter(req, res);
			}
		}else {
			req.getRequestDispatcher("dologin.com").forward(req, res);
		}
	}

}
