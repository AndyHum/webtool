package com.my.web.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PubUtil {
	public static String getPk(){
		return "pk_"+dateToString();
	}
	
	public static String dateToString(){
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		
		return sdf.format(date);
	}
	public static void main(String[] args) {
		System.out.println(getPk());
	}
}
