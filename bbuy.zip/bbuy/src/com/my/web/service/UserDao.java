package com.my.web.service;

import java.util.List;

import net.sf.ezmorph.bean.MorphDynaBean;

import com.my.web.entity.CustomerVO;
import com.my.web.entity.OrderVO;
import com.my.web.entity.ProductVO;

public interface UserDao {
	public boolean checkLogin(CustomerVO cust);
	
	public List<ProductVO> getProducts();
	
	public void checkOut(List<MorphDynaBean> pros,CustomerVO cust);
	
	public List<OrderVO> getMyOrders(CustomerVO cust);
	
	public List<OrderVO> getCustsInfo();
	
	public void deleteCustInfo(List<MorphDynaBean> lists);
	
	public List<ProductVO> getSellersInfo();
}
